package com.example.multiplayertest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FinalActivity_Login extends AppCompatActivity {
    private FirebaseDatabase database;
    private DatabaseReference playerRef;//reference represents a particular location in your Database
                            //and can be used for reading or writing data to that Database location
    private DatabaseReference playersRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_login);

        database = FirebaseDatabase.getInstance(); //instance (ID) provides a unique identifier for each instance of your app and a mechanism to authenticate and authorize actions

        EditText editField = findViewById(R.id.editField); //user types in username in editField
        Button loginButton = findViewById(R.id.loginButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //called when login button view has been clicked
                String playerName = editField.getText().toString(); //gets text -> string from editField
                playersRef = database.getReference("players"); //and registers playerName in Firebase players database
                playerRef = database.getReference("players/"+playerName);

                loginButton.setText("Logging in");
                loginButton.setEnabled(false);

                playersRef.addValueEventListener(new ValueEventListener() { //used to receive events about data changes at a location.
                                                    //Attach the listener to a location user addValueEventListener(ValueEventListener).
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Intent intent = new Intent(FinalActivity_Login.this, FinalActivity_Main2.class);
                        intent.putExtra("playerName", playerName); //sends this data from this activity to FinalActivity_Main2 activity
                        startActivity(intent);
                        finish();
                    }

                    //just in case it fails
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(getApplicationContext(), "Failed to Login!", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}