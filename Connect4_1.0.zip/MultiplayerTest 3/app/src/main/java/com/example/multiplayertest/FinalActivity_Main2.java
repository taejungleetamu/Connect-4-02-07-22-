package com.example.multiplayertest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FinalActivity_Main2 extends AppCompatActivity {

    private FirebaseDatabase database;
    private DatabaseReference roomRef;
    private DatabaseReference roomSRef;
    private String roomName;
    private String playerName;

    ListView listView;
    Button createRoomButton, signOutButton;
    ArrayList<String> roomsList;

    //assign 1 or 2 to player
    //1 is host/player who creates room, 2 is player who joins the room
    private int assignTurn = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_main2);

        listView = findViewById(R.id.listView);
        createRoomButton = findViewById(R.id.createRoomButton);
        signOutButton = findViewById(R.id.signOut);

        roomsList = new ArrayList<String>();
        database = FirebaseDatabase.getInstance();

        Intent intent = getIntent(); //gets intent from login activity
        playerName = intent.getStringExtra("playerName");//assings that intent data
        createRoomButton.setOnClickListener(new View.OnClickListener() { //listens for user to click on create a room
            @Override
            public void onClick(View view) {
                createRoomButton.setText("Creating Room");
                createRoomButton.setEnabled(false);
                roomName = playerName +  "'s room";
                roomRef = database.getReference("rooms/"+roomName+"/player1"); //gets database room and registers created room as player 1
                addRoomEventListener();
                roomRef.setValue(playerName); //saves data to a specified reference, replacing any existing data at that path
                assignTurn = 1; //player 1's input is registered as 1
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { //listen to when user clicks/join a created room
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                roomName = roomsList.get(i);
                roomRef = database.getReference("rooms/"+roomName+"/player2"); ////gets database room created from player1 & registers player2 in that room
                addRoomEventListener();
                roomRef.setValue(playerName);
                assignTurn = 2; //player 2's input is registered as 2
                database.getReference("rooms/"+roomName+"/turn").setValue(1); //makes sure the turn in the created room is player 1's value
            }
        });

        addRoomSeventListener();


        signOutButton.setOnClickListener(new View.OnClickListener() { //listener for signing out
            @Override
            public void onClick(View view) {
                startActivity(new Intent(FinalActivity_Main2.this, FinalActivity_Login.class));
                finish();
            }
        });
    }



    void addRoomEventListener(){
        roomRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Toast.makeText(getApplicationContext(), "starting activity", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(FinalActivity_Main2.this, FinalActivity_OnlineMode.class);
                intent.putExtra("roomName", roomName);
                intent.putExtra("turn", assignTurn);
                intent.putExtra("playerName", playerName);
                roomRef.removeEventListener(this);
                startActivity(intent);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Server Error!", Toast.LENGTH_SHORT).show();
                createRoomButton.setText("Create Room");
                createRoomButton.setEnabled(true);
            }
        });
    }


    //clear and listview format still need to work on (currently manually delete rooms on Firebase)
    void addRoomSeventListener(){
        roomSRef = database.getReference("rooms");
        roomSRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                roomsList.clear();
                Iterable<DataSnapshot> onlineRooms = snapshot.getChildren();
                for(DataSnapshot ds: onlineRooms){
                    roomsList.add(ds.getKey());
                }

                ArrayAdapter<String> arrayAdapter =  new ArrayAdapter<>(FinalActivity_Main2.this,
                        R.layout.listview_color, roomsList); //R.layout.listview_color specifically for color/format change
                listView.setAdapter(arrayAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Server Error!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}