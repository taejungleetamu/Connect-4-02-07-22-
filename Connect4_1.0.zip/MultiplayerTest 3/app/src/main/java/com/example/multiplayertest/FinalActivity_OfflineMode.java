package com.example.multiplayertest;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class FinalActivity_OfflineMode extends AppCompatActivity {

    boolean playing = true;
    private int turn = 1;  // to track player's turn in offline
    private static final int RESET_GAME = -2;  //send signal to reset game

    //grid
    private final int c = 7, r = 6;  // columns and rows of grid
    private int grid[][] = new int[r][c];  // a grid of 6*7

    //images
    private HashMap<String, ImageView> tokens = new HashMap<String, ImageView>();
    private ArrayList<Button> buttons = new ArrayList<Button>();
    private ImageView sampleToken;

    //text views
    private TextView playerText, winnerText;
    private int buttonPressed = -1;  //which button is pressed to select a column

    //room name
    private String roomName;

    //players
    private Player player1 = null, player2 = null;
    private Button resetButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_offline_mode);

        playerText = findViewById(R.id.playerText);
        winnerText = findViewById(R.id.winnerText);
        sampleToken = findViewById(R.id.sampleToken);

        //prepare the game
        prepareTokens();
        prepareButtons();
        resetGrid();

        player1 = new Player("Player 1", R.drawable.game_piece_red);
        player2= new Player("Player 2", R.drawable.game_piece_black);


        //update the whose turn it is through text and image on the top every turn
        switch(turn){
            case 1:
                playerText.setText(player1.name+" ");
                sampleToken.setImageResource(player1.imageRef);
                break;
            case 2:
                playerText.setText(player2.name+" ");
                sampleToken.setImageResource(player2.imageRef);
                break;

        }

        //reset Button
        resetButton = findViewById(R.id.resetButton);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetGrid();
                playing = true;
                resetButton.setVisibility(View.INVISIBLE);
                winnerText.setVisibility(View.INVISIBLE);
            }
        });
    }
/*
    //just a java multidimensional array, change it if becomes too much of an issue
    //java multidimensional array: (0,0) starts at top left

    i = 0   [50, 51, 52, 53, 54, 55, 56],
    i = 1   [40, 41, 42, 43, 44, 45, 46],
    i = 2   [30, 31, 32, 33, 34, 35, 36],
    i = 3   [20, 21, 22, 23, 24, 25, 26],
    i = 4   [10, 11, 12, 13, 14, 15, 16],
    i = 5   [00, 01, 02, 03, 04, 05, 06],
 */
    int dropPlayer_1(int col) {
        for(int i = r-1; i >= 0; i--) {
            if(grid[i][col] == 0) {
                grid[i][col] = 1;
                return r-1-i;
            }
        }
        return -1;
    }

    int dropPlayer_2(int col) {
        for(int i = r-1; i >= 0; i--) {
            if(grid[i][col] == 0) {
                grid[i][col] = 2;
                return r-1-i;
            }
        }
        return -1;
    }


    //checkers
    int checkWinner() {
        //check row
        for(int i = 0; i < r; i++) {
            for(int j = 0; j < c-3; j++) {
                if(
                        grid[i][j] != 0
                                &&	grid[i][j] == grid[i][j+1]
                                &&  grid[i][j+1] == grid[i][j+2]
                                &&  grid[i][j+2] == grid[i][j+3]
                )
                    return grid[i][j];
            }
        }

        //check column
        for(int i = 0; i < c; i++) {
            for(int j = r-1; j > 2; j--) {
                if(
                        grid[j][i] != 0
                                &&	grid[j][i] == grid[j-1][i]
                                &&  grid[j-1][i] == grid[j-2][i]
                                &&  grid[j-2][i] == grid[j-3][i]
                )
                    return grid[j][i];
            }
        }
        //check diagonal / top left to right bottom
        for(int i = 0; i < r-3; i++) {
            for(int j = 0; j < c-3; j++) {
                if(
                        grid[i][j] != 0
                                &&	grid[i][j] == grid[i+1][j+1]
                                &&  grid[i+1][j+1] == grid[i+2][j+2]
                                &&  grid[i+2][j+2] == grid[i+3][j+3]
                )
                    return grid[i][j];
            }
        }

        //check diagonal / top right to left bottom
        for(int i = r-1; i > 2; i--) {
            for(int j = 0; j < c-3; j++) {
                if(
                        grid[i][j] != 0
                                &&	grid[i][j] == grid[i-1][j+1]
                                &&  grid[i-1][j+1] == grid[i-2][j+2]
                                &&  grid[i-2][j+2] == grid[i-3][j+3]
                )
                    return grid[i][j];
            }
        }
        return 0;
    }

    void declareWinner(){
        int winner = checkWinner();
        if(winner != 0){
            if(winner == 1)
                winnerText.setText("Winner : "+player1.name);
            else
                winnerText.setText("Winner : "+player2.name);
            winnerText.setVisibility(View.VISIBLE);
            playing = false;
            resetButton.setVisibility(View.VISIBLE);
        }
    }

    void prepareButtons(){
        buttons.add(findViewById(R.id.button0));
        buttons.add(findViewById(R.id.button1));
        buttons.add(findViewById(R.id.button2));
        buttons.add(findViewById(R.id.button3));
        buttons.add(findViewById(R.id.button4));
        buttons.add(findViewById(R.id.button5));
        buttons.add(findViewById(R.id.button6));


        for(Button b: buttons){
            b.setBackgroundColor(Color.BLACK);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(!playing){
                        Toast.makeText(getApplicationContext(), "Game Not Started!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    buttonPressed = buttons.indexOf(b);
                    int row = -1;
                    switch(turn) {
                        case 1:
                            row = dropPlayer_1(buttonPressed);
                            updateGrid(row, buttonPressed, turn);
                            turn = 2;
                            break;
                        case 2:
                            row = dropPlayer_2(buttonPressed);
                            updateGrid(row, buttonPressed, turn);
                            turn = 1;
                            break;
                        default:
                            System.out.println("Error!");
                            playing = false;
                    }
                    declareWinner();  //if winner then this function will declare it
                    //update turn label
                    switch(turn){
                        case 1:
                            playerText.setText(player1.name+" ");
                            sampleToken.setImageResource(player1.imageRef);
                            break;
                        case 2:
                            playerText.setText(player2.name+" ");
                            sampleToken.setImageResource(player2.imageRef);
                            break;

                    }
                }
            });
        }
    }

    void prepareTokens(){
        tokens.put("0 0", (ImageView) findViewById(R.id.token00));
        tokens.put("0 1", (ImageView) findViewById(R.id.token01));
        tokens.put("0 2", (ImageView) findViewById(R.id.token02));
        tokens.put("0 3", (ImageView) findViewById(R.id.token03));
        tokens.put("0 4", (ImageView) findViewById(R.id.token04));
        tokens.put("0 5", (ImageView) findViewById(R.id.token05));
        tokens.put("0 6", (ImageView) findViewById(R.id.token06));
        tokens.put("1 0", (ImageView) findViewById(R.id.token10));
        tokens.put("1 1", (ImageView) findViewById(R.id.token11));
        tokens.put("1 2", (ImageView) findViewById(R.id.token12));
        tokens.put("1 3", (ImageView) findViewById(R.id.token13));
        tokens.put("1 4", (ImageView) findViewById(R.id.token14));
        tokens.put("1 5", (ImageView) findViewById(R.id.token15));
        tokens.put("1 6", (ImageView) findViewById(R.id.token16));
        tokens.put("2 0", (ImageView) findViewById(R.id.token20));
        tokens.put("2 1", (ImageView) findViewById(R.id.token21));
        tokens.put("2 2", (ImageView) findViewById(R.id.token22));
        tokens.put("2 3", (ImageView) findViewById(R.id.token23));
        tokens.put("2 4", (ImageView) findViewById(R.id.token24));
        tokens.put("2 5", (ImageView) findViewById(R.id.token25));
        tokens.put("2 6", (ImageView) findViewById(R.id.token26));
        tokens.put("3 0", (ImageView) findViewById(R.id.token30));
        tokens.put("3 1", (ImageView) findViewById(R.id.token31));
        tokens.put("3 2", (ImageView) findViewById(R.id.token32));
        tokens.put("3 3", (ImageView) findViewById(R.id.token33));
        tokens.put("3 4", (ImageView) findViewById(R.id.token34));
        tokens.put("3 5", (ImageView) findViewById(R.id.token35));
        tokens.put("3 6", (ImageView) findViewById(R.id.token36));
        tokens.put("4 0", (ImageView) findViewById(R.id.token40));
        tokens.put("4 1", (ImageView) findViewById(R.id.token41));
        tokens.put("4 2", (ImageView) findViewById(R.id.token42));
        tokens.put("4 3", (ImageView) findViewById(R.id.token43));
        tokens.put("4 4", (ImageView) findViewById(R.id.token44));
        tokens.put("4 5", (ImageView) findViewById(R.id.token45));
        tokens.put("4 6", (ImageView) findViewById(R.id.token46));
        tokens.put("5 0", (ImageView) findViewById(R.id.token50));
        tokens.put("5 1", (ImageView) findViewById(R.id.token51));
        tokens.put("5 2", (ImageView) findViewById(R.id.token52));
        tokens.put("5 3", (ImageView) findViewById(R.id.token53));
        tokens.put("5 4", (ImageView) findViewById(R.id.token54));
        tokens.put("5 5", (ImageView) findViewById(R.id.token55));
        tokens.put("5 6", (ImageView) findViewById(R.id.token56));

    }

    void resetGrid(){
        //clear 2d array grid
        for(int i = 0; i < r; i++) {
            for(int j = 0; j < c; j++) {
                grid[i][j] = 0;
            }
        }

        //clear visual grid
        for(int i = 0; i < r; i++) {
            for(int j = 0; j < c; j++) {
                String key = String.format("%d %d", i, j);
                ImageView currentToken = tokens.get(key);
                currentToken.setImageResource(R.drawable.custom_button);
            }
        }
    }

    void updateGrid(int row, int col, int turn){
        if(row < 0){
            //player loses his turn if selected already full Stack
            //turn shifts to opponent giving a message
            Toast.makeText(getApplicationContext(), "Stack "+col+" was full!", Toast.LENGTH_SHORT).show();
            return;
        }
        String key = String.format("%d %d", row, col);
        ImageView currentToken = tokens.get(key);
        switch(turn){
            case 1:
                currentToken.setImageResource(R.drawable.game_piece_red);
                break;
            case 2:
                currentToken.setImageResource(R.drawable.game_piece_black);
                break;
            default:
                currentToken.setImageResource(R.drawable.custom_button);
        }
    }
}