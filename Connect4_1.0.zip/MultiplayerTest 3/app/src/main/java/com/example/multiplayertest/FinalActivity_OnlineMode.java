package com.example.multiplayertest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot; //contains data from a Firebase Database location
import com.google.firebase.database.DatabaseError; //passed to callbacks when an operation failed
import com.google.firebase.database.DatabaseReference; //represents a particular location in your Database
import com.google.firebase.database.FirebaseDatabase; //entry point for accessing a Firebase Database
import com.google.firebase.database.ValueEventListener; //receive events about data changes at a location

import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.HashMap;

public class FinalActivity_OnlineMode extends AppCompatActivity {
    private FirebaseDatabase database;
    private DatabaseReference roomRef; //check if player is added in database on joining
    private DatabaseReference turnRef; //used by system to manage turns
    private DatabaseReference inputRef; //used by system to check inputs from users
    private DatabaseReference player2Ref; //used by player 1 to check if player 2 joined room

    boolean playing = false;
    private int assignedTurn = 1;
    private int currentTurn = 1; //check current turn of room using database
    private static final int resetGame = -2;

    //columns and rows of grid
    private final int c = 7, r = 6;
    private int grid[][] = new int[r][c]; //[6][7]

    private HashMap<String, ImageView> tokens = new HashMap<>(); //prepare prepareTokens
                                                                 //maps java row column arrays identifying values/keys into xml files
    private ArrayList<Button> buttons = new ArrayList<Button>();
    private ImageView sampleToken;

    private TextView playerText, winnerText;
    private String roomName;
    private Player player1 = null, player2 = null;
    private Button resetButton;
    private int buttonPressed = -1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_online_mode);

        playerText = findViewById(R.id.playerText);
        winnerText = findViewById(R.id.winnerText);
        sampleToken = findViewById(R.id.sampleToken);

        prepareTokens();
        prepareButtons();
        resetGrid();

        Intent intent = getIntent();
        roomName = intent.getStringExtra("roomName");
        assignedTurn = intent.getIntExtra("turn", 1);

        //prepare database
        database = FirebaseDatabase.getInstance();
        turnRef = database.getReference("rooms/"+roomName+"/turn");
        roomRef = database.getReference("rooms/"+roomName);
        player2Ref = database.getReference("rooms/"+roomName+"/player2");

        player1 = new Player("", R.drawable.game_piece_red);
        player2= new Player("", R.drawable.game_piece_black);


        if(assignedTurn == 1){  //host has to wait for 2nd player
            player1.name = intent.getStringExtra("playerName");
            playerText.setText(player1.name+" ");
            sampleToken.setImageResource(player1.imageRef);
            addPlayer2Listener();  //listens for opponent
        }else if(assignedTurn == 2){
            player2.name = intent.getStringExtra("playerName");
            playerText.setText(player2.name+" ");
            sampleToken.setImageResource(player2.imageRef);
            player2Ref.setValue(player2.name);
            addRoomListener(); //listens for player2 being added to room
        }

        addInputListener();
        addRoomTurnListener();

        resetButton = findViewById(R.id.resetButton);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetGrid();
                playing = true;
                inputRef.setValue(resetGame);
                resetButton.setVisibility(View.INVISIBLE);
            }
        });
    }



    //listens for player 2 being added to database
    //player 1 already in database (room creator)
    private void addRoomListener() {
        roomRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                player1.name = snapshot.child("/player1").getValue().toString();
                playing = true;
                roomRef.removeEventListener(this);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Server Error!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    //player 1 listener and setup when player 1 joins
    private void addPlayer1Listener() {
        ValueEventListener player1ValueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Object objectValue = snapshot.getValue();
                if (objectValue != null){
                    player1.name = objectValue.toString();
                    playing = true;
                    Toast.makeText(getApplicationContext(), player1.name+" joined!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Server Error!", Toast.LENGTH_SHORT).show();
            }
        };
    }

    //player 2 listener and setup when player 2 joins
    private void addPlayer2Listener(){
        ValueEventListener player2ValueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Object objectValue = snapshot.getValue();
                if (objectValue != null){
                    player2 = new Player("", R.drawable.game_piece_black);
                    player2.name = objectValue.toString();
                    playing = true;
                    Toast.makeText(getApplicationContext(), player2.name+" joined!", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Server Error!", Toast.LENGTH_SHORT).show();
            }
        };
        player2Ref.addValueEventListener(player2ValueEventListener);
    }



    private void addInputListener() {
        inputRef = database.getReference("rooms/"+roomName+"/input");
        inputRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Object objectValue = snapshot.getValue();  //object containing value of input from opponent
                int value = objectValue == null? -1 : Integer.parseInt(""+objectValue); //if there's no value in the database
                if(value == -1)
                    return;
                else if(value == resetGame){ //inputRef.setValue(resetGame) used earlier
                    resetGrid();
                    playing = true;
                    winnerText.setVisibility(View.GONE);
                    resetButton.setVisibility(View.GONE);
                    turnRef.setValue(1);
                    inputRef.setValue(-1);
                    return;
                }

                //opponent has made their turn
                int row = -1;
                switch (currentTurn){
                    case 1:
                        row = dropPlayer_1(value);
                        updateGrid(row, value, currentTurn);
                        break;
                    case 2:
                        row = dropPlayer_2(value);
                        updateGrid(row, value, currentTurn);
                        break;
                }
                declareWinner();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Server Error!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addRoomTurnListener() {
        turnRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Object objectValue = snapshot.getValue();
                if(objectValue != null)
                    currentTurn = Integer.parseInt(""+objectValue);
                //sets input value to -1 for next player
                inputRef.setValue(-1);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Server Error!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    //how tokens drop
    int dropPlayer_1(int col) {
        for(int i = r-1; i >= 0; i--) {
            if(grid[i][col] == 0) {
                grid[i][col] = 1;
                return r-1-i;
            }
        }
        return -1;
    }

    int dropPlayer_2(int col) {
        for(int i = r-1; i >= 0; i--) {
            if(grid[i][col] == 0) {
                grid[i][col] = 2;
                return r-1-i;
            }
        }
        return -1;
    }


    //checkers
    int checkWinner() {
        //check rows
        for(int i = 0; i < r; i++) {
            for(int j = 0; j < c-3; j++) {
                if(
                        grid[i][j] != 0
                                &&	grid[i][j] == grid[i][j+1]
                                &&  grid[i][j+1] == grid[i][j+2]
                                &&  grid[i][j+2] == grid[i][j+3]
                )
                    return grid[i][j];
            }
        }

        //check columns
        for(int i = 0; i < c; i++) {
            for(int j = r-1; j > 2; j--) {
                if(
                        grid[j][i] != 0
                                &&	grid[j][i] == grid[j-1][i]
                                &&  grid[j-1][i] == grid[j-2][i]
                                &&  grid[j-2][i] == grid[j-3][i]
                )
                    return grid[j][i];
            }
        }
        //check diagonal / top left to right bottom
        for(int i = 0; i < r-3; i++) {
            for(int j = 0; j < c-3; j++) {
                if(
                        grid[i][j] != 0
                                &&	grid[i][j] == grid[i+1][j+1]
                                &&  grid[i+1][j+1] == grid[i+2][j+2]
                                &&  grid[i+2][j+2] == grid[i+3][j+3]
                )
                    return grid[i][j];
            }
        }

        //check diagonal / top right to left bottom
        for(int i = r-1; i > 2; i--) {
            for(int j = 0; j < c-3; j++) {
                if(
                        grid[i][j] != 0
                                &&	grid[i][j] == grid[i-1][j+1]
                                &&  grid[i-1][j+1] == grid[i-2][j+2]
                                &&  grid[i-2][j+2] == grid[i-3][j+3]
                )
                    return grid[i][j];
            }
        }
        return 0;
    }


    void declareWinner(){
        int winner = checkWinner();
        if(winner != 0){
            if(winner == assignedTurn)
                winnerText.setText("You Win!");
            else
                winnerText.setText("You Lose!");
            winnerText.setVisibility(View.VISIBLE);
            playing = false;
            resetButton.setVisibility(View.VISIBLE);
        }
    }

    void prepareButtons(){
        buttons.add(findViewById(R.id.button0));
        buttons.add(findViewById(R.id.button1));
        buttons.add(findViewById(R.id.button2));
        buttons.add(findViewById(R.id.button3));
        buttons.add(findViewById(R.id.button4));
        buttons.add(findViewById(R.id.button5));
        buttons.add(findViewById(R.id.button6));

        for(Button b: buttons){
            b.setBackgroundColor(Color.WHITE);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(!playing){
                        Toast.makeText(getApplicationContext(), "Game Not Started!", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    buttonPressed = buttons.indexOf(b);
                    if(assignedTurn != currentTurn)
                        return;
                    //if its current player's turn
                    //update the database
                    switch(currentTurn) {
                        case 1:
                            inputRef.setValue(buttonPressed);
                            turnRef.setValue(2);
                            break;
                        case 2:
                            inputRef.setValue(buttonPressed);
                            turnRef.setValue(1);
                            break;
                        default:
                            System.out.println("Error!");
                            playing = false;
                    }
                    //update turn in room of database
                }
            });
        }
    }


    //String key = String.format("%d %d", i, j);
    void prepareTokens(){
        tokens.put("0 0", (ImageView) findViewById(R.id.token00));
        tokens.put("0 1", (ImageView) findViewById(R.id.token01));
        tokens.put("0 2", (ImageView) findViewById(R.id.token02));
        tokens.put("0 3", (ImageView) findViewById(R.id.token03));
        tokens.put("0 4", (ImageView) findViewById(R.id.token04));
        tokens.put("0 5", (ImageView) findViewById(R.id.token05));
        tokens.put("0 6", (ImageView) findViewById(R.id.token06));
        tokens.put("1 0", (ImageView) findViewById(R.id.token10));
        tokens.put("1 1", (ImageView) findViewById(R.id.token11));
        tokens.put("1 2", (ImageView) findViewById(R.id.token12));
        tokens.put("1 3", (ImageView) findViewById(R.id.token13));
        tokens.put("1 4", (ImageView) findViewById(R.id.token14));
        tokens.put("1 5", (ImageView) findViewById(R.id.token15));
        tokens.put("1 6", (ImageView) findViewById(R.id.token16));
        tokens.put("2 0", (ImageView) findViewById(R.id.token20));
        tokens.put("2 1", (ImageView) findViewById(R.id.token21));
        tokens.put("2 2", (ImageView) findViewById(R.id.token22));
        tokens.put("2 3", (ImageView) findViewById(R.id.token23));
        tokens.put("2 4", (ImageView) findViewById(R.id.token24));
        tokens.put("2 5", (ImageView) findViewById(R.id.token25));
        tokens.put("2 6", (ImageView) findViewById(R.id.token26));
        tokens.put("3 0", (ImageView) findViewById(R.id.token30));
        tokens.put("3 1", (ImageView) findViewById(R.id.token31));
        tokens.put("3 2", (ImageView) findViewById(R.id.token32));
        tokens.put("3 3", (ImageView) findViewById(R.id.token33));
        tokens.put("3 4", (ImageView) findViewById(R.id.token34));
        tokens.put("3 5", (ImageView) findViewById(R.id.token35));
        tokens.put("3 6", (ImageView) findViewById(R.id.token36));
        tokens.put("4 0", (ImageView) findViewById(R.id.token40));
        tokens.put("4 1", (ImageView) findViewById(R.id.token41));
        tokens.put("4 2", (ImageView) findViewById(R.id.token42));
        tokens.put("4 3", (ImageView) findViewById(R.id.token43));
        tokens.put("4 4", (ImageView) findViewById(R.id.token44));
        tokens.put("4 5", (ImageView) findViewById(R.id.token45));
        tokens.put("4 6", (ImageView) findViewById(R.id.token46));
        tokens.put("5 0", (ImageView) findViewById(R.id.token50));
        tokens.put("5 1", (ImageView) findViewById(R.id.token51));
        tokens.put("5 2", (ImageView) findViewById(R.id.token52));
        tokens.put("5 3", (ImageView) findViewById(R.id.token53));
        tokens.put("5 4", (ImageView) findViewById(R.id.token54));
        tokens.put("5 5", (ImageView) findViewById(R.id.token55));
        tokens.put("5 6", (ImageView) findViewById(R.id.token56));

    }
    //clear 2d array grid, and visual grid
    void resetGrid(){
        for(int i = 0; i < r; i++) {
            for(int j = 0; j < c; j++) {
                grid[i][j] = 0;
            }
        }
        for(int i = 0; i < r; i++) {
            for(int j = 0; j < c; j++) {
                String key = String.format("%d %d", i, j);
                ImageView currentToken = tokens.get(key);
                currentToken.setImageResource(R.drawable.custom_button);
            }
        }
    }


    //break full stack
    void updateGrid(int row, int col, int turn){
        if(row < 0){
            Toast.makeText(getApplicationContext(), "Stack "+col+" was full!", Toast.LENGTH_SHORT).show();
            return;
        }
        String key = String.format("%d %d", row, col);
        ImageView currentToken = tokens.get(key);

        switch(turn){
            case 1:
                currentToken.setImageResource(R.drawable.game_piece_red);
                break;
            case 2:
                currentToken.setImageResource(R.drawable.game_piece_black);
                break;
            default:
                currentToken.setImageResource(R.drawable.custom_button);
        }
    }
}