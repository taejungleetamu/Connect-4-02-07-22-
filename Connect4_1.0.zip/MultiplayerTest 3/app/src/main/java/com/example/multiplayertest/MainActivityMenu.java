package com.example.multiplayertest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivityMenu extends AppCompatActivity implements View.OnClickListener {

    public CardView offlinebutton, onlinebutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        onlinebutton = (CardView) findViewById(R.id.button1);
        offlinebutton = (CardView) findViewById(R.id.button2);

        onlinebutton.setOnClickListener(this); //setOnClickListener links a listener with attributes
        offlinebutton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent i;

        switch (v.getId()) {
            //onlinebutton leads to FinalActivity_Login page
            case R.id.button1:
                i = new Intent(this,FinalActivity_Login.class);
                startActivity(i);
                break;

            //offline leads to FinalActivity_OfflineMode page
            case R.id.button2:
                i = new Intent(this,FinalActivity_OfflineMode.class);
                startActivity(i);
                break;
        }
    }
}