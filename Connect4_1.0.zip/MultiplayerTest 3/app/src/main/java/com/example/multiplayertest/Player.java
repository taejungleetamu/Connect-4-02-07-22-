package com.example.multiplayertest;

public class Player {
    String name;
    int imageRef;
    Player(String name, int imageRef){
        this.name = name;
        this.imageRef = imageRef;
    }
}